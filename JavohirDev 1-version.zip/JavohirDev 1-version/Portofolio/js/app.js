
function sendFeedback(){
    var data = [];

    var text = document.getElementById('text').value;
    var email = document.getElementById('email').value;
    var option = document.getElementById('option').value;
    var textarea = document.getElementById('textarea').value;

    var yourFeedback = {
      name: text,
      email: email,
      option: option,
      textarea: textarea
    } /**IT'S FIELD FOR SAVE, WHEN WRITE TO INPUTS**/

    data.push(yourFeedback);
    console.log(yourFeedback);
    
    document.getElementById('form-group').style.opacity = 0;
    setTimeout(function(){
        var formGroup = document.getElementById('form-group').classList.toggle('d-none');
        var infoRegister = document.getElementById('info').classList.toggle('d-block');
    }, 1000);
}

const toTop = document.querySelector(".to-top");

window.addEventListener("scroll", () => {
  if (window.pageYOffset > 100) {
    toTop.classList.add("active");
  } else {
    toTop.classList.remove("active");
  }
})